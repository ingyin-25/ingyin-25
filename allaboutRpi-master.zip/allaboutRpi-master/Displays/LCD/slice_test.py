s = "hello"
print s[1:4]
print s[:]

