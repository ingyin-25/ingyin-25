function ledon(){
    document.location="cgi-bin/ledon.cgi";
}
function ledoff(){
    document.location="cgi-bin/ledoff.cgi";
}

